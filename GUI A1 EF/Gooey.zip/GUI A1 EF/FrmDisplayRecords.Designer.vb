﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmDisplayRecords
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.ListBox2 = New System.Windows.Forms.ListBox
        Me.ListBox3 = New System.Windows.Forms.ListBox
        Me.ListBox4 = New System.Windows.Forms.ListBox
        Me.ListBox5 = New System.Windows.Forms.ListBox
        Me.ListBox6 = New System.Windows.Forms.ListBox
        Me.ListBox7 = New System.Windows.Forms.ListBox
        Me.ListBox8 = New System.Windows.Forms.ListBox
        Me.LblName = New System.Windows.Forms.Label
        Me.LblA1 = New System.Windows.Forms.Label
        Me.LblA2 = New System.Windows.Forms.Label
        Me.LblA3 = New System.Windows.Forms.Label
        Me.LblExam = New System.Windows.Forms.Label
        Me.LblMark = New System.Windows.Forms.Label
        Me.LblGrade = New System.Windows.Forms.Label
        Me.LblPoints = New System.Windows.Forms.Label
        Me.BtnMenu2 = New System.Windows.Forms.Button
        Me.BtnDisplay = New System.Windows.Forms.Button
        Me.TxtAvgMark = New System.Windows.Forms.TextBox
        Me.TxtBestStudent = New System.Windows.Forms.TextBox
        Me.TxtWorstStudent = New System.Windows.Forms.TextBox
        Me.LblAvg = New System.Windows.Forms.Label
        Me.LblBest = New System.Windows.Forms.Label
        Me.LblWorst = New System.Windows.Forms.Label
        Me.TxtBestMark = New System.Windows.Forms.TextBox
        Me.TxtWorstMark = New System.Windows.Forms.TextBox
        Me.LblBestName = New System.Windows.Forms.Label
        Me.LblWorstName = New System.Windows.Forms.Label
        Me.LblWorstMark = New System.Windows.Forms.Label
        Me.LblBestMark = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.ListBox1.ForeColor = System.Drawing.Color.SteelBlue
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 14
        Me.ListBox1.Location = New System.Drawing.Point(91, 152)
        Me.ListBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(93, 130)
        Me.ListBox1.TabIndex = 0
        '
        'ListBox2
        '
        Me.ListBox2.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.ListBox2.ForeColor = System.Drawing.Color.SteelBlue
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 14
        Me.ListBox2.Location = New System.Drawing.Point(215, 152)
        Me.ListBox2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(93, 130)
        Me.ListBox2.TabIndex = 1
        '
        'ListBox3
        '
        Me.ListBox3.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.ListBox3.ForeColor = System.Drawing.Color.SteelBlue
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.ItemHeight = 14
        Me.ListBox3.Location = New System.Drawing.Point(339, 152)
        Me.ListBox3.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(93, 130)
        Me.ListBox3.TabIndex = 2
        '
        'ListBox4
        '
        Me.ListBox4.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.ListBox4.ForeColor = System.Drawing.Color.SteelBlue
        Me.ListBox4.FormattingEnabled = True
        Me.ListBox4.ItemHeight = 14
        Me.ListBox4.Location = New System.Drawing.Point(463, 152)
        Me.ListBox4.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ListBox4.Name = "ListBox4"
        Me.ListBox4.Size = New System.Drawing.Size(93, 130)
        Me.ListBox4.TabIndex = 3
        '
        'ListBox5
        '
        Me.ListBox5.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.ListBox5.ForeColor = System.Drawing.Color.SteelBlue
        Me.ListBox5.FormattingEnabled = True
        Me.ListBox5.ItemHeight = 14
        Me.ListBox5.Location = New System.Drawing.Point(587, 152)
        Me.ListBox5.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ListBox5.Name = "ListBox5"
        Me.ListBox5.Size = New System.Drawing.Size(93, 130)
        Me.ListBox5.TabIndex = 4
        '
        'ListBox6
        '
        Me.ListBox6.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.ListBox6.ForeColor = System.Drawing.Color.SteelBlue
        Me.ListBox6.FormattingEnabled = True
        Me.ListBox6.ItemHeight = 14
        Me.ListBox6.Location = New System.Drawing.Point(711, 152)
        Me.ListBox6.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ListBox6.Name = "ListBox6"
        Me.ListBox6.Size = New System.Drawing.Size(93, 130)
        Me.ListBox6.TabIndex = 5
        '
        'ListBox7
        '
        Me.ListBox7.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.ListBox7.ForeColor = System.Drawing.Color.SteelBlue
        Me.ListBox7.FormattingEnabled = True
        Me.ListBox7.ItemHeight = 14
        Me.ListBox7.Location = New System.Drawing.Point(835, 152)
        Me.ListBox7.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ListBox7.Name = "ListBox7"
        Me.ListBox7.Size = New System.Drawing.Size(93, 130)
        Me.ListBox7.TabIndex = 6
        '
        'ListBox8
        '
        Me.ListBox8.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.ListBox8.ForeColor = System.Drawing.Color.SteelBlue
        Me.ListBox8.FormattingEnabled = True
        Me.ListBox8.ItemHeight = 14
        Me.ListBox8.Location = New System.Drawing.Point(959, 152)
        Me.ListBox8.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ListBox8.Name = "ListBox8"
        Me.ListBox8.Size = New System.Drawing.Size(93, 130)
        Me.ListBox8.TabIndex = 7
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblName.ForeColor = System.Drawing.Color.White
        Me.LblName.Location = New System.Drawing.Point(109, 127)
        Me.LblName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(43, 14)
        Me.LblName.TabIndex = 8
        Me.LblName.Text = "Name"
        '
        'LblA1
        '
        Me.LblA1.AutoSize = True
        Me.LblA1.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblA1.ForeColor = System.Drawing.Color.White
        Me.LblA1.Location = New System.Drawing.Point(248, 127)
        Me.LblA1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblA1.Name = "LblA1"
        Me.LblA1.Size = New System.Drawing.Size(20, 14)
        Me.LblA1.TabIndex = 9
        Me.LblA1.Text = "A1"
        '
        'LblA2
        '
        Me.LblA2.AutoSize = True
        Me.LblA2.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblA2.ForeColor = System.Drawing.Color.White
        Me.LblA2.Location = New System.Drawing.Point(369, 127)
        Me.LblA2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblA2.Name = "LblA2"
        Me.LblA2.Size = New System.Drawing.Size(25, 14)
        Me.LblA2.TabIndex = 10
        Me.LblA2.Text = "A2"
        '
        'LblA3
        '
        Me.LblA3.AutoSize = True
        Me.LblA3.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblA3.ForeColor = System.Drawing.Color.White
        Me.LblA3.Location = New System.Drawing.Point(493, 127)
        Me.LblA3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblA3.Name = "LblA3"
        Me.LblA3.Size = New System.Drawing.Size(25, 14)
        Me.LblA3.TabIndex = 11
        Me.LblA3.Text = "A3"
        '
        'LblExam
        '
        Me.LblExam.AutoSize = True
        Me.LblExam.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblExam.ForeColor = System.Drawing.Color.White
        Me.LblExam.Location = New System.Drawing.Point(605, 127)
        Me.LblExam.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblExam.Name = "LblExam"
        Me.LblExam.Size = New System.Drawing.Size(42, 14)
        Me.LblExam.TabIndex = 12
        Me.LblExam.Text = "Exam"
        '
        'LblMark
        '
        Me.LblMark.AutoSize = True
        Me.LblMark.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblMark.ForeColor = System.Drawing.Color.White
        Me.LblMark.Location = New System.Drawing.Point(725, 127)
        Me.LblMark.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblMark.Name = "LblMark"
        Me.LblMark.Size = New System.Drawing.Size(49, 14)
        Me.LblMark.TabIndex = 13
        Me.LblMark.Text = "Mark%"
        '
        'LblGrade
        '
        Me.LblGrade.AutoSize = True
        Me.LblGrade.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblGrade.ForeColor = System.Drawing.Color.White
        Me.LblGrade.Location = New System.Drawing.Point(852, 127)
        Me.LblGrade.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblGrade.Name = "LblGrade"
        Me.LblGrade.Size = New System.Drawing.Size(45, 14)
        Me.LblGrade.TabIndex = 14
        Me.LblGrade.Text = "Grade"
        '
        'LblPoints
        '
        Me.LblPoints.AutoSize = True
        Me.LblPoints.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblPoints.ForeColor = System.Drawing.Color.White
        Me.LblPoints.Location = New System.Drawing.Point(975, 127)
        Me.LblPoints.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblPoints.Name = "LblPoints"
        Me.LblPoints.Size = New System.Drawing.Size(47, 14)
        Me.LblPoints.TabIndex = 15
        Me.LblPoints.Text = "Points"
        '
        'BtnMenu2
        '
        Me.BtnMenu2.BackColor = System.Drawing.Color.White
        Me.BtnMenu2.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.BtnMenu2.ForeColor = System.Drawing.Color.SteelBlue
        Me.BtnMenu2.Location = New System.Drawing.Point(16, 583)
        Me.BtnMenu2.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.BtnMenu2.Name = "BtnMenu2"
        Me.BtnMenu2.Size = New System.Drawing.Size(111, 62)
        Me.BtnMenu2.TabIndex = 16
        Me.BtnMenu2.Text = "Menu"
        Me.BtnMenu2.UseVisualStyleBackColor = False
        '
        'BtnDisplay
        '
        Me.BtnDisplay.BackColor = System.Drawing.Color.White
        Me.BtnDisplay.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.BtnDisplay.ForeColor = System.Drawing.Color.SteelBlue
        Me.BtnDisplay.Location = New System.Drawing.Point(135, 583)
        Me.BtnDisplay.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.BtnDisplay.Name = "BtnDisplay"
        Me.BtnDisplay.Size = New System.Drawing.Size(175, 62)
        Me.BtnDisplay.TabIndex = 17
        Me.BtnDisplay.Text = "Display Report"
        Me.BtnDisplay.UseVisualStyleBackColor = False
        '
        'TxtAvgMark
        '
        Me.TxtAvgMark.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.TxtAvgMark.ForeColor = System.Drawing.Color.SteelBlue
        Me.TxtAvgMark.Location = New System.Drawing.Point(531, 536)
        Me.TxtAvgMark.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtAvgMark.Name = "TxtAvgMark"
        Me.TxtAvgMark.Size = New System.Drawing.Size(148, 21)
        Me.TxtAvgMark.TabIndex = 18
        '
        'TxtBestStudent
        '
        Me.TxtBestStudent.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.TxtBestStudent.ForeColor = System.Drawing.Color.SteelBlue
        Me.TxtBestStudent.Location = New System.Drawing.Point(531, 564)
        Me.TxtBestStudent.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtBestStudent.Name = "TxtBestStudent"
        Me.TxtBestStudent.Size = New System.Drawing.Size(148, 21)
        Me.TxtBestStudent.TabIndex = 19
        '
        'TxtWorstStudent
        '
        Me.TxtWorstStudent.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.TxtWorstStudent.ForeColor = System.Drawing.Color.SteelBlue
        Me.TxtWorstStudent.Location = New System.Drawing.Point(531, 592)
        Me.TxtWorstStudent.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtWorstStudent.Name = "TxtWorstStudent"
        Me.TxtWorstStudent.Size = New System.Drawing.Size(148, 21)
        Me.TxtWorstStudent.TabIndex = 20
        '
        'LblAvg
        '
        Me.LblAvg.AutoSize = True
        Me.LblAvg.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblAvg.ForeColor = System.Drawing.Color.White
        Me.LblAvg.Location = New System.Drawing.Point(377, 540)
        Me.LblAvg.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblAvg.Name = "LblAvg"
        Me.LblAvg.Size = New System.Drawing.Size(96, 14)
        Me.LblAvg.TabIndex = 21
        Me.LblAvg.Text = "Average Mark"
        '
        'LblBest
        '
        Me.LblBest.AutoSize = True
        Me.LblBest.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblBest.ForeColor = System.Drawing.Color.White
        Me.LblBest.Location = New System.Drawing.Point(377, 568)
        Me.LblBest.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblBest.Name = "LblBest"
        Me.LblBest.Size = New System.Drawing.Size(90, 14)
        Me.LblBest.TabIndex = 22
        Me.LblBest.Text = "Best Student"
        '
        'LblWorst
        '
        Me.LblWorst.AutoSize = True
        Me.LblWorst.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblWorst.ForeColor = System.Drawing.Color.White
        Me.LblWorst.Location = New System.Drawing.Point(377, 596)
        Me.LblWorst.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblWorst.Name = "LblWorst"
        Me.LblWorst.Size = New System.Drawing.Size(99, 14)
        Me.LblWorst.TabIndex = 23
        Me.LblWorst.Text = "Worst Student"
        '
        'TxtBestMark
        '
        Me.TxtBestMark.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.TxtBestMark.ForeColor = System.Drawing.Color.SteelBlue
        Me.TxtBestMark.Location = New System.Drawing.Point(797, 564)
        Me.TxtBestMark.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtBestMark.Name = "TxtBestMark"
        Me.TxtBestMark.Size = New System.Drawing.Size(148, 21)
        Me.TxtBestMark.TabIndex = 24
        '
        'TxtWorstMark
        '
        Me.TxtWorstMark.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.TxtWorstMark.ForeColor = System.Drawing.Color.SteelBlue
        Me.TxtWorstMark.Location = New System.Drawing.Point(797, 592)
        Me.TxtWorstMark.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TxtWorstMark.Name = "TxtWorstMark"
        Me.TxtWorstMark.Size = New System.Drawing.Size(148, 21)
        Me.TxtWorstMark.TabIndex = 25
        '
        'LblBestName
        '
        Me.LblBestName.AutoSize = True
        Me.LblBestName.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblBestName.ForeColor = System.Drawing.Color.White
        Me.LblBestName.Location = New System.Drawing.Point(713, 568)
        Me.LblBestName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblBestName.Name = "LblBestName"
        Me.LblBestName.Size = New System.Drawing.Size(43, 14)
        Me.LblBestName.TabIndex = 26
        Me.LblBestName.Text = "Name"
        '
        'LblWorstName
        '
        Me.LblWorstName.AutoSize = True
        Me.LblWorstName.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblWorstName.ForeColor = System.Drawing.Color.White
        Me.LblWorstName.Location = New System.Drawing.Point(713, 596)
        Me.LblWorstName.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblWorstName.Name = "LblWorstName"
        Me.LblWorstName.Size = New System.Drawing.Size(43, 14)
        Me.LblWorstName.TabIndex = 27
        Me.LblWorstName.Text = "Name"
        '
        'LblWorstMark
        '
        Me.LblWorstMark.AutoSize = True
        Me.LblWorstMark.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblWorstMark.ForeColor = System.Drawing.Color.White
        Me.LblWorstMark.Location = New System.Drawing.Point(975, 596)
        Me.LblWorstMark.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblWorstMark.Name = "LblWorstMark"
        Me.LblWorstMark.Size = New System.Drawing.Size(38, 14)
        Me.LblWorstMark.TabIndex = 29
        Me.LblWorstMark.Text = "Mark"
        '
        'LblBestMark
        '
        Me.LblBestMark.AutoSize = True
        Me.LblBestMark.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.LblBestMark.ForeColor = System.Drawing.Color.White
        Me.LblBestMark.Location = New System.Drawing.Point(975, 568)
        Me.LblBestMark.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LblBestMark.Name = "LblBestMark"
        Me.LblBestMark.Size = New System.Drawing.Size(38, 14)
        Me.LblBestMark.TabIndex = 28
        Me.LblBestMark.Text = "Mark"
        '
        'FrmDisplayRecords
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(1145, 658)
        Me.Controls.Add(Me.LblWorstMark)
        Me.Controls.Add(Me.LblBestMark)
        Me.Controls.Add(Me.LblWorstName)
        Me.Controls.Add(Me.LblBestName)
        Me.Controls.Add(Me.TxtWorstMark)
        Me.Controls.Add(Me.TxtBestMark)
        Me.Controls.Add(Me.LblWorst)
        Me.Controls.Add(Me.LblBest)
        Me.Controls.Add(Me.LblAvg)
        Me.Controls.Add(Me.TxtWorstStudent)
        Me.Controls.Add(Me.TxtBestStudent)
        Me.Controls.Add(Me.TxtAvgMark)
        Me.Controls.Add(Me.BtnDisplay)
        Me.Controls.Add(Me.BtnMenu2)
        Me.Controls.Add(Me.LblPoints)
        Me.Controls.Add(Me.LblGrade)
        Me.Controls.Add(Me.LblMark)
        Me.Controls.Add(Me.LblExam)
        Me.Controls.Add(Me.LblA3)
        Me.Controls.Add(Me.LblA2)
        Me.Controls.Add(Me.LblA1)
        Me.Controls.Add(Me.LblName)
        Me.Controls.Add(Me.ListBox8)
        Me.Controls.Add(Me.ListBox7)
        Me.Controls.Add(Me.ListBox6)
        Me.Controls.Add(Me.ListBox5)
        Me.Controls.Add(Me.ListBox4)
        Me.Controls.Add(Me.ListBox3)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.ListBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "FrmDisplayRecords"
        Me.Text = "Display Records"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox4 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox5 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox6 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox7 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox8 As System.Windows.Forms.ListBox
    Friend WithEvents LblName As System.Windows.Forms.Label
    Friend WithEvents LblA1 As System.Windows.Forms.Label
    Friend WithEvents LblA2 As System.Windows.Forms.Label
    Friend WithEvents LblA3 As System.Windows.Forms.Label
    Friend WithEvents LblExam As System.Windows.Forms.Label
    Friend WithEvents LblMark As System.Windows.Forms.Label
    Friend WithEvents LblGrade As System.Windows.Forms.Label
    Friend WithEvents LblPoints As System.Windows.Forms.Label
    Friend WithEvents BtnMenu2 As System.Windows.Forms.Button
    Friend WithEvents BtnDisplay As System.Windows.Forms.Button
    Friend WithEvents TxtAvgMark As System.Windows.Forms.TextBox
    Friend WithEvents TxtBestStudent As System.Windows.Forms.TextBox
    Friend WithEvents TxtWorstStudent As System.Windows.Forms.TextBox
    Friend WithEvents LblAvg As System.Windows.Forms.Label
    Friend WithEvents LblBest As System.Windows.Forms.Label
    Friend WithEvents LblWorst As System.Windows.Forms.Label
    Friend WithEvents TxtBestMark As System.Windows.Forms.TextBox
    Friend WithEvents TxtWorstMark As System.Windows.Forms.TextBox
    Friend WithEvents LblBestName As System.Windows.Forms.Label
    Friend WithEvents LblWorstName As System.Windows.Forms.Label
    Friend WithEvents LblWorstMark As System.Windows.Forms.Label
    Friend WithEvents LblBestMark As System.Windows.Forms.Label
End Class
