﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAddRecords
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnAdd = New System.Windows.Forms.Button
        Me.BtnMenu1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'BtnAdd
        '
        Me.BtnAdd.BackColor = System.Drawing.Color.White
        Me.BtnAdd.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.BtnAdd.ForeColor = System.Drawing.Color.SteelBlue
        Me.BtnAdd.Location = New System.Drawing.Point(479, 188)
        Me.BtnAdd.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(187, 43)
        Me.BtnAdd.TabIndex = 0
        Me.BtnAdd.Text = "Add Records"
        Me.BtnAdd.UseVisualStyleBackColor = False
        '
        'BtnMenu1
        '
        Me.BtnMenu1.BackColor = System.Drawing.Color.White
        Me.BtnMenu1.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.BtnMenu1.ForeColor = System.Drawing.Color.SteelBlue
        Me.BtnMenu1.Location = New System.Drawing.Point(479, 425)
        Me.BtnMenu1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.BtnMenu1.Name = "BtnMenu1"
        Me.BtnMenu1.Size = New System.Drawing.Size(187, 43)
        Me.BtnMenu1.TabIndex = 1
        Me.BtnMenu1.Text = "Menu"
        Me.BtnMenu1.UseVisualStyleBackColor = False
        '
        'FrmAddRecords
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(1145, 658)
        Me.Controls.Add(Me.BtnMenu1)
        Me.Controls.Add(Me.BtnAdd)
        Me.Font = New System.Drawing.Font("Orbitron Medium", 8.25!)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "FrmAddRecords"
        Me.Text = "Add Records"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BtnAdd As System.Windows.Forms.Button
    Friend WithEvents BtnMenu1 As System.Windows.Forms.Button
End Class
