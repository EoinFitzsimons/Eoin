
public class ExamResults {
	public static void main(String[] args) {
		
		int resultArray[] = new int [6];
					resultArray[0]=69;
					resultArray[1]=75;
					resultArray[2]=43;
					resultArray[3]=55;
					resultArray[4]=35;
					resultArray[5]=87;
					
			System.out.println("Marks in Java- " + resultArray[0]);
			System.out.println("Marks in OOP- " + resultArray[1]);
			System.out.println("Marks in GUI- " + resultArray[2]);
			System.out.println("Marks in PM- " + resultArray[3]);
			System.out.println("Marks in PPD- " + resultArray[4]);
			System.out.println("Marks in Communication- " + resultArray[5]);
		
	}
}

