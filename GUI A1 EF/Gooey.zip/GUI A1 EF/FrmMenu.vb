﻿Public Class FrmMenu

    Private Sub BtnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExit.Click
        Me.Hide()
        FrmLogin.Show()
    End Sub

    Private Sub BtnShowRecords_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnShowRecords.Click
        Me.Hide()
        FrmDisplayRecords.Show()
    End Sub

    Private Sub BtnAddRecords_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAddRecords.Click
        Me.Hide()
        FrmAddRecords.Show()
    End Sub


    
    Private Sub FrmMenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        On Error Resume Next
        If user = "Eoin" Then
            BtnAddRecords.Visible = True
        End If

        If user = "Guest" Then
            BtnAddRecords.Visible = False
        End If


    End Sub
End Class