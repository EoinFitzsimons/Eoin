﻿Public Class FrmAddRecords
    Dim studentname As String
    Dim Assignment1 As Integer
    Dim Assignment2 As Integer
    Dim Assignment3 As Integer
    Dim Exam As Integer
    Dim allmarks As Integer
    Dim CAO As Integer
    Dim Grade As String
    Private Sub _Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAdd.Click
        On Error Resume Next 'Stops program crashing'
        FileOpen(1, My.Application.Info.DirectoryPath & "\results.dat", OpenMode.Append)
        studentname = InputBox("Enter name(or click cancel to stop):")
1:      Assignment1 = (InputBox("Enter a mark between 1 and 20", "Assignment1"))
2:      Assignment2 = (InputBox("Enter a mark between 1 and 20", "Assignment2"))
3:      Assignment3 = (InputBox("Enter a mark between 1 and 30", "Assignment3"))
4:      Exam = (InputBox("Enter a mark between 1 and 30", "Exam"))

        allmarks = Assignment1 + Assignment2 + Assignment3 + Exam
        Grade = (InputBox("Enter QQI grade ", "Grade "))
        CAO = (InputBox("Enter CAO points ", "CAO POINTS "))

        WriteLine(1, studentname, Assignment1, Assignment2, Assignment3, Exam, Grade, CAO)
    End Sub
    Private Sub BtnMenu1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnMenu1.Click
        Me.Hide()
        FrmMenu.Show()
    End Sub
End Class
