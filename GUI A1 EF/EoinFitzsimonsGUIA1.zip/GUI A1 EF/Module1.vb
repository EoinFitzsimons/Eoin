﻿Module Module1
    Public user As String
End Module
