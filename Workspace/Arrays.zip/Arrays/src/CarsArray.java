/*
public class CarsArray {

	public static void main(String[] args) {
			String[] Cars = {"Volvo", "BMW", "Ford", "Mazda"};
			System.out.println(Cars[0]);
	}
}

public class CarsArray {

	public static void main(String[] args) {
			String[] Cars = {"Volvo", "BMW", "Ford", "Mazda"};
			Cars[0] = "Opel";
			System.out.println(Cars[0]);
	}
}
*/
/*
public class CarsArray {

	public static void main(String[] args) {
			String[] Cars = {"Volvo", "BMW", "Ford", "Mazda"};
			System.out.println(Cars.length);
	}
}
*/

public class CarsArray {

	public static void main(String[] args) {
			String[] Cars = {"Volvo", "BMW", "Ford", "Mazda"};
			for (int i = 0; i < Cars.length; i++) {
			System.out.println(Cars[i]);
		}
	}
}